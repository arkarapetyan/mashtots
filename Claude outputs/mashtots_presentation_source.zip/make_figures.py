"""Figures for the Mashtots presentation (static PDF charts and image grids)."""
import json, sqlite3, sys
from pathlib import Path
import numpy as np, torch, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm

sys.path.insert(0, "/home/claude/mashtots")
from torchvision.io import read_image
import torchvision.transforms as T
from scripts.data.data_module import build_train_transform, PIXEL_MEAN, PIXEL_STD
from scripts.utils.transforms import FastElasticTransform

OUT = Path("/home/claude/presentation/figures")
DATA = Path("/mnt/user-data/uploads/mashtots/data/Train/Train")
BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, GRID = "#0b0b0b", "#52514e", "#e6e5e1"
for f in fm.findSystemFonts():
    if "FiraSans" in f or "DejaVuSans" in f:
        fm.fontManager.addfont(f)
plt.rcParams.update({
    "font.family": ["Fira Sans", "DejaVu Sans"], "font.size": 16,
    "axes.edgecolor": INK2, "axes.labelcolor": INK2, "xtick.color": INK2, "ytick.color": INK2,
    "axes.spines.top": False, "axes.spines.right": False, "axes.grid": True,
    "grid.color": GRID, "grid.linewidth": 0.8, "axes.axisbelow": True,
    "figure.dpi": 200, "savefig.bbox": "tight", "savefig.pad_inches": 0.05,
    "legend.frameon": False, "axes.titlecolor": INK, "axes.titlesize": 17,
})
ARM = __import__("yaml").safe_load(open("/home/claude/mashtots/configs/train_config.yaml"))["callback"]["class_names"]

def img(cls, i):
    return read_image(str(DATA / str(cls) / f"{i}.png")).float().div(255)

def show(ax, t, title=None):
    ax.imshow(t.squeeze().numpy(), cmap="gray", vmin=0, vmax=1)
    ax.set_xticks([]); ax.set_yticks([]); ax.grid(False)
    for s in ax.spines.values(): s.set_visible(False)
    if title: ax.set_title(title, fontsize=13, color=INK2, pad=4)

# ---------- 1. confusable pairs (real samples) ----------
pairs = [(16, 27), (48, 59), (2, 41)]
fig, axes = plt.subplots(3, 7, figsize=(10, 4.6), gridspec_kw={"width_ratios": [1, 1, 1, 0.25, 1, 1, 1]})
for r, (a, b) in enumerate(pairs):
    for j in range(3):
        show(axes[r, j], img(a, j + 1)); show(axes[r, 4 + j], img(b, j + 1))
    axes[r, 3].axis("off")
    axes[r, 0].set_ylabel(ARM[a], rotation=0, fontsize=22, color=INK, labelpad=22, va="center")
    axes[r, 6].yaxis.set_label_position("right")
    axes[r, 6].set_ylabel(ARM[b], rotation=0, fontsize=22, color=INK, labelpad=22, va="center")
plt.subplots_adjust(wspace=0.08, hspace=0.1)
fig.savefig(OUT / "confusable_pairs.png"); plt.close(fig)

# ---------- 2. augmentation examples ----------
torch.manual_seed(3)
tf = build_train_transform()
fig, axes = plt.subplots(3, 7, figsize=(10.5, 4.8))
for r, (cls, i) in enumerate([(0, 1), (16, 2), (41, 3)]):
    x = img(cls, i)
    show(axes[r, 0], x, "original" if r == 0 else None)
    for j in range(1, 7):
        y = tf(x) * PIXEL_STD + PIXEL_MEAN
        show(axes[r, j], y.clamp(0, 1), "augmented" if (r == 0 and j == 1) else None)
plt.subplots_adjust(wspace=0.06, hspace=0.06)
fig.savefig(OUT / "augmentation.png"); plt.close(fig)

# ---------- 3. old vs new elastic ----------
torch.manual_seed(7)
x = img(16, 1)
old, new = T.ElasticTransform(alpha=1.0, sigma=0.1), FastElasticTransform(alpha=40.0, sigma=5.0)
fig, axes = plt.subplots(1, 5, figsize=(10, 2.4))
show(axes[0], x, "original")
show(axes[1], old(x), "old setting"); show(axes[2], old(x), "old setting")
show(axes[3], new(x), "new setting"); show(axes[4], new(x), "new setting")
plt.subplots_adjust(wspace=0.06)
fig.savefig(OUT / "elastic_old_new.png"); plt.close(fig)

# ---------- metrics from MLflow ----------
con = sqlite3.connect("/tmp/mlflow_user.db")
rid = {n: con.execute("select run_uuid from runs where run_uuid like ?", (p + "%",)).fetchone()[0]
       for n, p in [("resnet", "1096a94e"), ("vit", "4c48a65f")]}
def series(run, key):
    return [v for _, v in con.execute("select step, value from metrics where run_uuid=? and key=? order by step, timestamp", (rid[run], key))]

# ---------- 4. validation accuracy curves ----------
fig, ax = plt.subplots(figsize=(7.5, 4.6))
offsets = {"resnet": (12, 14, "left"), "vit": (-12, -30, "right")}
for run, color, label in [("resnet", BLUE, "ResNet-18"), ("vit", ORANGE, "ViT")]:
    va = np.array(series(run, "val_acc")) * 100
    ep = np.arange(len(va))
    b = int(va.argmax())
    ax.plot(ep, va, color=color, lw=2, label=f"{label}: best {va[b]:.2f}%\n(epoch {b}, dot)")
    ax.scatter([b], [va[b]], s=70, color=color, edgecolor="white", linewidth=2, zorder=5)
ax.set_ylim(90, 98); ax.set_xlim(0, 200)
ax.set_xlabel("epoch"); ax.set_ylabel("validation accuracy (%)")
ax.annotate("ViT stopped\nearly (epoch 175)", (175, 96.1), xytext=(168, 93.4), color=INK2, fontsize=14, ha="center",
            arrowprops=dict(arrowstyle="-", color=INK2, lw=1))
ax.legend(loc="lower right", fontsize=14)
fig.savefig(OUT / "val_curves.png"); plt.close(fig)

# ---------- 5. train vs validation (small multiples, shared y) ----------
fig, axes = plt.subplots(1, 2, figsize=(10, 3.6), sharey=True)
for ax, run, title in [(axes[0], "resnet", "ResNet-18"), (axes[1], "vit", "ViT")]:
    tr, va = np.array(series(run, "train_acc")) * 100, np.array(series(run, "val_acc")) * 100
    ax.plot(tr, color=BLUE, lw=2); ax.plot(va, color=ORANGE, lw=2)
    ax.set_title(title, loc="left"); ax.set_xlabel("epoch"); ax.set_ylim(88, 100)
    n = len(tr); ax.set_xlim(0, n * 1.32)
    ax.text(n + n * 0.02, tr[-1], f"{tr[-1]:.1f}%", color=INK, ha="left", va="center", fontsize=15)
    ax.text(n + n * 0.02, va[-1], f"{va[-1]:.1f}%", color=INK, ha="left", va="center", fontsize=15)
axes[0].set_ylabel("accuracy (%)")
from matplotlib.lines import Line2D
fig.legend([Line2D([], [], color=BLUE, lw=2), Line2D([], [], color=ORANGE, lw=2)], ["training (augmented)", "validation"],
           loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.08), fontsize=15)
fig.savefig(OUT / "train_vs_val.png"); plt.close(fig)

# ---------- 6. learning-rate schedules (small multiples) ----------
steps_per_epoch = 63054 / 128
fig, axes = plt.subplots(1, 2, figsize=(10, 3.3))
for ax, run, key, title, color in [(axes[0], "resnet", "lr-SGD", "ResNet-18: SGD + OneCycle", BLUE),
                                   (axes[1], "vit", "lr-AdamW/pg1", "ViT: AdamW, warmup + cosine", ORANGE)]:
    rows = con.execute("select step, value from metrics where run_uuid=? and key=? order by step", (rid[run], key)).fetchall()
    s, v = np.array(rows).T
    scale, unit = (1, "learning rate") if run == "resnet" else (1e4, "learning rate (×10⁻⁴)")
    ax.plot(s / steps_per_epoch, v * scale, color=color, lw=2)
    ax.set_title(title, loc="left"); ax.set_xlabel("epoch"); ax.set_ylabel(unit)
fig.tight_layout(); fig.savefig(OUT / "lr_schedules.png"); plt.close(fig)

# ---------- 7. leaderboard: private-leaderboard error rate ----------
models = ["ResNet-18", "ViT", "Ensemble\n+ TTA"]
priv = np.array([0.97071, 0.96954, 0.97598]); pub = np.array([0.97101, 0.96961, 0.97554])
err = (1 - priv) * 100
fig, ax = plt.subplots(figsize=(6.6, 3.8))
y = np.arange(len(models))[::-1]
bars = ax.barh(y, err, color=[BLUE, ORANGE, AQUA], height=0.55)
for yi, e, p in zip(y, err, priv):
    ax.text(e + 0.05, yi, f"{e:.2f}%", va="center", color=INK, fontsize=16)
ax.set_yticks(y, models); ax.set_xlim(0, 3.6); ax.grid(axis="y", visible=False)
ax.set_xlabel("private-leaderboard error rate (%)\nlower is better")
fig.savefig(OUT / "leaderboard.png"); plt.close(fig)

# ---------- 8. most-confused pairs (ResNet, best epoch) ----------
rows = []
for line in open("/mnt/user-data/uploads/mashtots/mlartifacts/1/1096a94e732249d4817b7a60b48b609a/artifacts/confusion_matrix/top_pairs_epoch_79.txt").read().splitlines()[2:12]:
    left, cnt = line.split(" | ")[0], int(line.split(" | ")[1])
    t, p = left.split(" -> ")
    ti, pi = int(t.split("(")[1][:-1]), int(p.split("(")[1][:-1])
    rows.append((f"{ARM[ti]} → {ARM[pi]}", cnt, (ti + 39) % 78 == pi))
fig, ax = plt.subplots(figsize=(6.8, 4.8))
y = np.arange(len(rows))[::-1]
ax.barh(y, [c for _, c, _ in rows], color=[ORANGE if case else BLUE for *_, case in rows], height=0.6)
for yi, (_, c, _) in zip(y, rows):
    ax.text(c + 0.2, yi, str(c), va="center", color=INK, fontsize=15)
ax.set_yticks(y, [n for n, *_ in rows], fontsize=18); ax.grid(axis="y", visible=False)
ax.set_xlabel("validation errors (197 in total)")
ax.legend([plt.Rectangle((0, 0), 1, 1, color=BLUE), plt.Rectangle((0, 0), 1, 1, color=ORANGE)],
          ["look-alike letters", "same letter, wrong case"], loc="lower right", fontsize=15)
fig.savefig(OUT / "confused_pairs.png"); plt.close(fig)
print("figures:", sorted(p.name for p in OUT.iterdir()))

# ---------- 9. dataset samples: uppercase row, lowercase twins below ----------
upper = [0, 2, 11, 23, 31, 38]
fig, axes = plt.subplots(2, 6, figsize=(10, 3.9))
for j, u in enumerate(upper):
    for r, cls in enumerate([u, u + 39]):
        show(axes[r, j], img(cls, 1))
        axes[r, j].set_title(f"{ARM[cls]}  ({cls})", fontsize=15, color=INK, pad=5)
plt.subplots_adjust(wspace=0.08, hspace=0.3)
fig.savefig(OUT / "samples.png"); plt.close(fig)
print("samples done")
